/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p4komponen;

import p4komponen.Framenya.MainFrm2;

/**
 *
 * @author USER
 */
public class p4Komponen2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        MainFrm2 i = new MainFrm2();
        i.setVisible(true);
    }
    
}
